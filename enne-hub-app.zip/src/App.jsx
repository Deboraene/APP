import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function EnneHubApp() {
  const [step, setStep] = useState(1);
  const [networks, setNetworks] = useState({ instagram: false, facebook: false, linkedin: false });
  const [selectedNetwork, setSelectedNetwork] = useState("instagram");

  const renderLogin = () => (
    <Card className="max-w-md mx-auto mt-10 p-6 text-center">
      <CardContent>
        <h1 className="text-xl font-bold text-[#B388EB] mb-4">Bem-vindo ao Enne Hub!</h1>
        <Button className="w-full mb-2 bg-[#B388EB]">Entrar com Google</Button>
        <Button className="w-full mb-4 bg-[#B388EB]">Entrar com Facebook</Button>
        <Button variant="outline" onClick={() => setStep(2)}>
          Avançar
        </Button>
      </CardContent>
    </Card>
  );

  const renderConnect = () => (
    <Card className="max-w-md mx-auto mt-10 p-6">
      <CardContent>
        <h2 className="text-lg font-bold mb-4">Conecte suas redes sociais</h2>
        <div className="space-y-2">
          {Object.entries(networks).map(([key, value]) => (
            <label key={key} className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={value}
                onChange={() => setNetworks({ ...networks, [key]: !value })}
              />
              {key.charAt(0).toUpperCase() + key.slice(1)}
            </label>
          ))}
        </div>
        <Button className="mt-4 w-full bg-[#B388EB]" onClick={() => setStep(3)}>
          Ir para o Painel
        </Button>
      </CardContent>
    </Card>
  );

  const renderDashboard = () => (
    <div className="max-w-xl mx-auto mt-6 p-4">
      <Tabs defaultValue="instagram" onValueChange={setSelectedNetwork}>
        <TabsList className="grid grid-cols-3">
          <TabsTrigger value="instagram">Instagram</TabsTrigger>
          <TabsTrigger value="facebook">Facebook</TabsTrigger>
          <TabsTrigger value="linkedin">LinkedIn</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="grid grid-cols-2 gap-4 mt-4">
        <Card><CardContent className="p-4">Postagens hoje: <strong>3</strong></CardContent></Card>
        <Card><CardContent className="p-4">Impressões: <strong>+1.200</strong></CardContent></Card>
        <Card><CardContent className="p-4">Melhor horário: <strong>13h</strong></CardContent></Card>
      </div>

      <Card className="mt-4">
        <CardContent className="p-4">
          <p className="font-semibold">Sugestão da IA:</p>
          <p>
            Hoje é um bom dia para postar sobre tendências da sua área. Que tal um conteúdo em
            formato de vídeo curto?
          </p>
        </CardContent>
      </Card>

      <Button className="w-full mt-4 bg-[#B388EB]">+ Agendar Nova Postagem</Button>
    </div>
  );

  return <main>{step === 1 ? renderLogin() : step === 2 ? renderConnect() : renderDashboard()}</main>;
}